import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertarJugador {
    private static void insertarDatos() throws SQLException, IOException {
        PreparedStatement ps = cnx.prepareStatement(
                "INSERT INTO jugador (RangoI, Titulo, Nombre, Federacion, ELO ,Nacional, FIDE_ID, ID_Nacional, OrigenClub, Hotel, Comunidad_Valenciana, RangoF, TipoTorneo) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Rango inicial");
        int RangoI = Integer.parseInt(br.readLine());
        System.out.println("Título: ");
        String titulo = br.readLine();
        System.out.println("Nombre del jugador: ");
        String NomJugador = br.readLine();
        System.out.println("Federación: ");
        String Federacion = br.readLine();
        System.out.println("ELO: ");
        int elo = Integer.parseInt(br.readLine());
        System.out.println("Nacional: ");
        String nacionalidad = br.readLine();
        System.out.println("FIDE_ID: ");
        int Fide_id = Integer.parseInt(br.readLine());
        System.out.println("ID_NACIONAL: ");
        int idNacional = Integer.parseInt(br.readLine());
        System.out.println("Origen club");
        String origenClub = br.readLine();
        System.out.println("Hotel: ");
        boolean hotel = Boolean.parseBoolean(br.readLine());
        System.out.println("Comunidad Valenciana: ");
        boolean cv = Boolean.parseBoolean(br.readLine());
        System.out.println("Rango final: ");
        int RangoF = Integer.parseInt(br.readLine());
        System.out.println("Tipo torneo: ");
        //char tipoTorneo = br.readLine().charAt(0);
        char tipoTorneo = 'A';

        double salarioEmpleado = Double.parseDouble(br.readLine());
        ps.setInt(1, RangoI);
        ps.setString(2, titulo);
        ps.setString(3, NomJugador);
        ps.setString(4, Federacion);
        ps.setInt(5, elo);
        ps.setString(6, nacionalidad);
        ps.setInt(7, Fide_id);
        ps.setInt(8, idNacional);
        ps.setString(9, origenClub);
        ps.setBoolean(10, hotel);
        ps.setBoolean(11, cv);
        ps.setInt(12, RangoF);
        ps.setString(13, String.valueOf(tipoTorneo));

        ps.executeUpdate();
        ps.close();
    }

    public static void main(String[] args) throws SQLException, IOException {

    insertarDatos();
    }

}
