package com.example.demo2;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.*;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Objects;

public class MainGestor extends Application {
    @Override
    public void start(Stage stage) throws IOException, SQLException {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(MainGestor.class.getResource("login.fxml"));
            Image icon = new Image(Objects.requireNonNull(getClass().getResourceAsStream("/img/logo64.png")));
            Scene scene = new Scene(fxmlLoader.load(), 1080, 640);
            stage.setTitle("Benidorm Open Chess 2024 - Iniciar sesión");
            stage.setScene(scene);
            stage.getIcons().add(icon);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch();
    }
}