package com.example.demo2;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class JugadorController implements Initializable {

    @FXML
    private CheckBox idCheckHotel;

    @FXML
    private CheckBox idCheckCV;

    @FXML
    private TextField idTFCLUB;

    @FXML
    private TextField idTFELO;

    @FXML
    private TextField idTFFIDE_ID;

    @FXML
    private TextField idTFFed;

    @FXML
    private TextField idTFID_NAC;

    @FXML
    private TextField idTFNac;

    @FXML
    private TextField idTFNombre;

    @FXML
    private TextField idTFRangoI;

    @FXML
    private TextField idTFTitulo;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Inicializar componentes si es necesario, pero no re-crear los controles
        System.out.println("idTFNombre: " + idTFNombre);
        System.out.println("idTFTitulo: " + idTFTitulo);
        System.out.println("idTFFed: " + idTFFed);
        System.out.println("idTFELO: " + idTFELO);
        System.out.println("idTFNac: " + idTFNac);
        System.out.println("idTFFIDE_ID: " + idTFFIDE_ID);
        System.out.println("idTFID_NAC: " + idTFID_NAC);
        System.out.println("idTFCLUB: " + idTFCLUB);
        System.out.println("idCheckHotel: " + idCheckHotel);
        System.out.println("idCheckCV: " + idCheckCV);
    }

    @FXML
    public void ventanaEditar(ObservableList<Jugador> jugadores, Jugador j) throws IOException {
        // Cargar el archivo FXML
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("terminar.fxml"));
        Parent root = fxmlLoader.load();

        // Obtener el controlador de la nueva escena
        JugadorController nuevoControlador = fxmlLoader.getController();

        // Setear la información del jugador en los campos usando el nuevo controlador
        nuevoControlador.setJugador(j);

        // Crear y mostrar la nueva ventana
        Image icon = new Image(Objects.requireNonNull(getClass().getResourceAsStream("/img/logo64.png")));
        Scene scene = new Scene(root, 540, 640);
        Stage stage = new Stage();
        stage.setTitle("Benidorm Open Chess 2024 - Editar jugador");
        stage.setScene(scene);
        stage.setResizable(false);
        stage.getIcons().add(icon);
        stage.show();
    }

    public Jugador setJugador(Jugador j) {
        idTFNombre.setText(j.getNomjug());
        idTFTitulo.setText(j.getTitulo());
        idTFFed.setText(j.getFederacion());
        idTFELO.setText(String.valueOf(j.getElo()));
        idTFNac.setText(String.valueOf(j.getNac()));
        idTFFIDE_ID.setText(String.valueOf(j.getFide_id()));
        idTFID_NAC.setText(String.valueOf(j.getId_nac()));
        idTFCLUB.setText(j.getClub());
        idCheckHotel.setSelected(j.isHotel());
        idCheckCV.setSelected(j.isCv());

        String nombre = this.idTFNombre.getText();
        String titulo = this.idTFTitulo.getText();
        String elo = this.idTFELO.getText();
        String federacion = this.idTFFed.getText();
        String Nac = this.idTFNac.getText();
        String fideID = this.idTFFIDE_ID.getText();
        String club = this.idTFCLUB.getText();
        String idNac = this.idTFID_NAC.getText();
        Boolean hotel = this.idCheckHotel.isSelected();
        Boolean cv = this.idCheckCV.isSelected();

        Jugador jugadorEditado = new Jugador(j.getRangoI(), titulo, nombre, federacion, Integer.valueOf(elo), Integer.valueOf(Nac), Integer.valueOf(fideID), Integer.valueOf(idNac), club, hotel, cv, j.getRangoF() ,j.getTipotorneo());
        return jugadorEditado;
    }
}
