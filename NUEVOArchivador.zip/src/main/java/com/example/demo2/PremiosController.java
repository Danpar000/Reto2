package com.example.demo2;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.input.MouseEvent;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.util.ResourceBundle;

public class PremiosController implements Initializable {
    Connection connection = DBUtils.connection;
    String typeTorneo = DBUtils.typeTorneo;

    @FXML
    private Button idBtnVolver;

    @FXML
    private TableColumn<?, ?> idCategoria;

    @FXML
    private TableColumn<?, ?> idImporte;

    @FXML
    private Label idLabelTipoTorneo;

    @FXML
    private TableColumn<?, ?> idNombre;

    @FXML
    private TableColumn<?, ?> idPuesto;

    @FXML
    private TableColumn<?, ?> idRangoF;

    @FXML
    private TableColumn<?, ?> idRangoI;


    @FXML
    void volver(MouseEvent event) throws IOException {
        DBUtils.changeScene("testnuevo - Copy.fxml", "Benidorm Chess Open 2024 - Jugadores Open " + typeTorneo, typeTorneo, 1080, 640);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        idLabelTipoTorneo.setText("TORNEO " + typeTorneo + " - LISTADO GANADORES");
    }
}
